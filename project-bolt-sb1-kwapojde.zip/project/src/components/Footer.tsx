import React from 'react';
import { Link } from 'react-router-dom';
import { Github, Twitter, Mail, Clock } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-space-blue bg-opacity-80 backdrop-blur-sm py-8 relative z-10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <Link to="/" className="flex items-center justify-center md:justify-start space-x-2">
              <Clock className="h-6 w-6 text-space-glow" />
              <span className="font-display text-xl font-bold text-white">TimeTesseract</span>
            </Link>
            <p className="text-cosmos-300 mt-2 text-center md:text-left">
              Exploring time through the lens of the cosmos
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6 md:mb-0">
            <div className="text-center md:text-left">
              <h4 className="text-space-glow font-display mb-3">Navigation</h4>
              <ul className="space-y-2">
                <li>
                  <Link to="/" className="text-cosmos-200 hover:text-space-glow transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-cosmos-200 hover:text-space-glow transition-colors">
                    About
                  </Link>
                </li>
                <li>
                  <Link to="/faq" className="text-cosmos-200 hover:text-space-glow transition-colors">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>

            <div className="text-center md:text-left">
              <h4 className="text-space-glow font-display mb-3">Tools</h4>
              <ul className="space-y-2">
                <li>
                  <a href="/#days-from-date" className="text-cosmos-200 hover:text-space-glow transition-colors">
                    Days From Date
                  </a>
                </li>
                <li>
                  <a href="/#day-of-week" className="text-cosmos-200 hover:text-space-glow transition-colors">
                    Day of Week
                  </a>
                </li>
                <li>
                  <a href="/#days-between" className="text-cosmos-200 hover:text-space-glow transition-colors">
                    Days Between
                  </a>
                </li>
                <li>
                  <a href="/#time-difference" className="text-cosmos-200 hover:text-space-glow transition-colors">
                    Time Difference
                  </a>
                </li>
              </ul>
            </div>

            <div className="text-center md:text-left">
              <h4 className="text-space-glow font-display mb-3">Connect</h4>
              <div className="flex space-x-4 justify-center md:justify-start">
                <a href="#" className="text-cosmos-200 hover:text-space-glow transition-colors">
                  <Github className="h-5 w-5" />
                </a>
                <a href="#" className="text-cosmos-200 hover:text-space-glow transition-colors">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="mailto:contact@timetesseract.com" className="text-cosmos-200 hover:text-space-glow transition-colors">
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-cosmos-700 border-opacity-30 mt-8 pt-8 text-center">
          <p className="text-cosmos-400 text-sm">
            &copy; {currentYear} TimeTesseract. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;