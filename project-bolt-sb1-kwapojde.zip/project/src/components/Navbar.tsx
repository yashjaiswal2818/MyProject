import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Clock, Menu, X, Info, HelpCircle } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close menu when location changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <nav
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? 'bg-space-blue bg-opacity-80 backdrop-blur-sm shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link
            to="/"
            className="flex items-center space-x-2 text-space-glow hover:text-white transition-colors duration-300"
          >
            <Clock className="h-8 w-8" />
            <span className="font-display text-xl font-bold">TimeTesseract</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-6">
            <Link
              to="/"
              className={`transition-colors duration-300 hover:text-space-glow ${
                location.pathname === '/' ? 'text-space-glow' : 'text-white'
              }`}
            >
              Home
            </Link>
            <Link
              to="/about"
              className={`transition-colors duration-300 hover:text-space-glow ${
                location.pathname === '/about' ? 'text-space-glow' : 'text-white'
              }`}
            >
              About
            </Link>
            <Link
              to="/faq"
              className={`transition-colors duration-300 hover:text-space-glow ${
                location.pathname === '/faq' ? 'text-space-glow' : 'text-white'
              }`}
            >
              FAQ
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white hover:text-space-glow transition-colors duration-300"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div
          className={`md:hidden transition-all duration-300 ease-in-out overflow-hidden ${
            isMenuOpen ? 'max-h-56 py-4' : 'max-h-0 py-0'
          }`}
        >
          <div className="flex flex-col space-y-4">
            <Link
              to="/"
              className="flex items-center space-x-2 transition-colors duration-300 hover:text-space-glow"
            >
              <Clock className="h-5 w-5" />
              <span>Home</span>
            </Link>
            <Link
              to="/about"
              className="flex items-center space-x-2 transition-colors duration-300 hover:text-space-glow"
            >
              <Info className="h-5 w-5" />
              <span>About</span>
            </Link>
            <Link
              to="/faq"
              className="flex items-center space-x-2 transition-colors duration-300 hover:text-space-glow"
            >
              <HelpCircle className="h-5 w-5" />
              <span>FAQ</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;