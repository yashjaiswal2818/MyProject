import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface TimeToolCardProps {
  id: string;
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const TimeToolCard: React.FC<TimeToolCardProps> = ({ id, title, icon, children }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleAccordion = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div id={id} className="card-glow mb-8 transition-all duration-300">
      <div
        className="flex items-center justify-between cursor-pointer"
        onClick={toggleAccordion}
      >
        <div className="flex items-center space-x-3">
          <div className="text-space-glow">{icon}</div>
          <h3 className="text-xl md:text-2xl font-display">{title}</h3>
        </div>
        <button
          aria-label={isOpen ? "Close section" : "Open section"}
          className="text-cosmos-300 hover:text-space-glow transition-colors"
        >
          {isOpen ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
        </button>
      </div>
      
      <div className={`accordion-content ${isOpen ? 'open' : ''} mt-4`}>
        {children}
      </div>
    </div>
  );
};

export default TimeToolCard;