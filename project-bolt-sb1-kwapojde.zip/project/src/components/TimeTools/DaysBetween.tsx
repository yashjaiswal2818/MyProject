import React, { useState } from 'react';
import { CalendarRange, ArrowRight, Copy } from 'lucide-react';
import FactDisplay from './FactDisplay';

const DaysBetween: React.FC = () => {
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [result, setResult] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  const calculateDaysBetween = () => {
    setError(null);
    
    if (!startDate) {
      setError('Please select a start date');
      return;
    }
    
    if (!endDate) {
      setError('Please select an end date');
      return;
    }
    
    try {
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      // Reset time part to compare just the dates
      start.setHours(0, 0, 0, 0);
      end.setHours(0, 0, 0, 0);
      
      // Calculate days
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      setResult(diffDays);
      setShowResult(true);
    } catch (err) {
      setError('Invalid date format');
      console.error('Error calculating days between:', err);
    }
  };

  const copyResult = () => {
    if (result !== null) {
      const textToCopy = `There are ${result} days between ${startDate} and ${endDate}.`;
      navigator.clipboard.writeText(textToCopy)
        .then(() => {
          console.log('Result copied to clipboard');
        })
        .catch(err => {
          console.error('Failed to copy:', err);
        });
    }
  };

  return (
    <div>
      <div className="space-y-4">
        <div>
          <label htmlFor="start-date" className="block text-cosmos-200 mb-2">
            Start Date
          </label>
          <input
            id="start-date"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="input-field w-full"
          />
        </div>
        
        <div>
          <label htmlFor="end-date" className="block text-cosmos-200 mb-2">
            End Date
          </label>
          <input
            id="end-date"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="input-field w-full"
          />
          {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
        </div>
        
        <button
          onClick={calculateDaysBetween}
          className="btn btn-primary w-full flex items-center justify-center space-x-2"
        >
          <span>Show Result</span>
          <ArrowRight size={16} />
        </button>
      </div>
      
      {showResult && result !== null && (
        <div className="mt-6 p-4 bg-space-purple bg-opacity-20 rounded-lg animate-fade-in">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-display text-white">Result</h4>
            <button
              onClick={copyResult}
              className="text-cosmos-300 hover:text-space-glow transition-colors"
              aria-label="Copy result"
            >
              <Copy size={16} />
            </button>
          </div>
          <p className="text-2xl font-display text-space-glow mt-2">
            {result} {result === 1 ? 'day' : 'days'}
          </p>
          <p className="text-cosmos-200 text-sm mt-1">
            {result === 0
              ? "These dates are the same day"
              : `There ${result === 1 ? 'is' : 'are'} ${result} ${
                  result === 1 ? 'day' : 'days'
                } between ${startDate} and ${endDate}`}
          </p>
          
          <FactDisplay toolName="DaysBetween" />
        </div>
      )}
    </div>
  );
};

export default DaysBetween;