import React, { useState } from 'react';
import { Clock, ArrowRight, Copy } from 'lucide-react';
import FactDisplay from './FactDisplay';

interface TimeDifferenceResult {
  hours: number;
  minutes: number;
  seconds: number;
  totalSeconds: number;
}

const TimeDifference: React.FC = () => {
  const [startDateTime, setStartDateTime] = useState<string>('');
  const [endDateTime, setEndDateTime] = useState<string>('');
  const [result, setResult] = useState<TimeDifferenceResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [loading, setLoading] = useState(false);

  const calculateTimeDifference = () => {
    setError(null);
    
    if (!startDateTime) {
      setError('Please select a start date and time');
      return;
    }
    
    if (!endDateTime) {
      setError('Please select an end date and time');
      return;
    }
    
    try {
      setLoading(true);
      
      // Simulate loading for UX purposes
      setTimeout(() => {
        const start = new Date(startDateTime);
        const end = new Date(endDateTime);
        
        // Calculate difference in seconds
        const diffSeconds = Math.abs(end.getTime() - start.getTime()) / 1000;
        
        // Convert to hours, minutes, seconds
        const hours = Math.floor(diffSeconds / 3600);
        const minutes = Math.floor((diffSeconds % 3600) / 60);
        const seconds = Math.floor(diffSeconds % 60);
        
        setResult({ hours, minutes, seconds, totalSeconds: diffSeconds });
        setShowResult(true);
        setLoading(false);
      }, 500); // Short loading simulation
    } catch (err) {
      setError('Invalid date or time format');
      setLoading(false);
      console.error('Error calculating time difference:', err);
    }
  };

  const copyResult = () => {
    if (result !== null) {
      const textToCopy = `Time difference: ${result.hours} hours, ${result.minutes} minutes, ${result.seconds} seconds`;
      navigator.clipboard.writeText(textToCopy)
        .then(() => {
          console.log('Result copied to clipboard');
        })
        .catch(err => {
          console.error('Failed to copy:', err);
        });
    }
  };

  const formatDateTime = (dateTimeString: string) => {
    const date = new Date(dateTimeString);
    return date.toLocaleString();
  };

  return (
    <div>
      <div className="space-y-4">
        <div>
          <label htmlFor="start-datetime" className="block text-cosmos-200 mb-2">
            Start Date and Time
          </label>
          <input
            id="start-datetime"
            type="datetime-local"
            value={startDateTime}
            onChange={(e) => setStartDateTime(e.target.value)}
            className="input-field w-full"
          />
          <p className="text-cosmos-300 text-sm mt-1">
            Format: MM/DD/YYYY HH:MM (24-hour format)
          </p>
        </div>
        
        <div>
          <label htmlFor="end-datetime" className="block text-cosmos-200 mb-2">
            End Date and Time
          </label>
          <input
            id="end-datetime"
            type="datetime-local"
            value={endDateTime}
            onChange={(e) => setEndDateTime(e.target.value)}
            className="input-field w-full"
          />
          {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
        </div>
        
        <button
          onClick={calculateTimeDifference}
          disabled={loading}
          className="btn btn-primary w-full flex items-center justify-center space-x-2"
        >
          {loading ? (
            <span>Calculating...</span>
          ) : (
            <>
              <span>Show Result</span>
              <ArrowRight size={16} />
            </>
          )}
        </button>
      </div>
      
      {showResult && result !== null && (
        <div className="mt-6 p-4 bg-space-purple bg-opacity-20 rounded-lg animate-fade-in">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-display text-white">Result</h4>
            <button
              onClick={copyResult}
              className="text-cosmos-300 hover:text-space-glow transition-colors"
              aria-label="Copy result"
            >
              <Copy size={16} />
            </button>
          </div>
          
          <div className="grid grid-cols-3 gap-2 mt-3 text-center">
            <div className="bg-space-dark bg-opacity-50 p-2 rounded-lg">
              <p className="text-2xl font-display text-space-glow">
                {result.hours}
              </p>
              <p className="text-xs text-cosmos-300">hours</p>
            </div>
            <div className="bg-space-dark bg-opacity-50 p-2 rounded-lg">
              <p className="text-2xl font-display text-space-glow">
                {result.minutes}
              </p>
              <p className="text-xs text-cosmos-300">minutes</p>
            </div>
            <div className="bg-space-dark bg-opacity-50 p-2 rounded-lg">
              <p className="text-2xl font-display text-space-glow">
                {result.seconds}
              </p>
              <p className="text-xs text-cosmos-300">seconds</p>
            </div>
          </div>
          
          <p className="text-cosmos-200 text-sm mt-3">
            Between {formatDateTime(startDateTime)} and {formatDateTime(endDateTime)}
          </p>
          
          <FactDisplay toolName="TimeDifference" />
        </div>
      )}
    </div>
  );
};

export default TimeDifference;