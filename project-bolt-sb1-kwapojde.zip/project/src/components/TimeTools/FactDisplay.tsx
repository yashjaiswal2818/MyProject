import React, { useState, useEffect } from 'react';
import { TypeAnimation } from 'react-type-animation';
import { RefreshCw } from 'lucide-react';

interface FactDisplayProps {
  toolName: string;
}

interface Fact {
  text: string;
  category: string;
}

const FactDisplay: React.FC<FactDisplayProps> = ({ toolName }) => {
  const [fact, setFact] = useState<Fact | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchFact = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/fact');
      
      if (!response.ok) {
        throw new Error('Failed to fetch fact');
      }
      
      const data = await response.json();
      setFact(data.fact);
      
      // Log tool usage
      await fetch('/api/log', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          tool: toolName,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (err) {
      setError('Could not load a fun fact. Please try again later.');
      console.error('Error fetching fact:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFact();
  }, [toolName]);

  if (loading) {
    return (
      <div className="mt-4 py-3 px-4 bg-space-dark bg-opacity-40 rounded-lg animate-pulse">
        <div className="h-4 bg-cosmos-700 bg-opacity-30 rounded w-3/4 mb-2"></div>
        <div className="h-4 bg-cosmos-700 bg-opacity-30 rounded w-1/2"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mt-4 py-3 px-4 bg-space-dark bg-opacity-40 rounded-lg text-cosmos-300">
        {error}
      </div>
    );
  }

  return (
    <div className="mt-4 py-3 px-4 bg-space-dark bg-opacity-40 rounded-lg animate-fade-in">
      <div className="flex justify-between items-start mb-2">
        <h4 className="text-space-glow font-display text-sm">Did You Know?</h4>
        <button
          onClick={fetchFact}
          className="text-cosmos-300 hover:text-space-glow transition-colors"
          aria-label="Get another fact"
        >
          <RefreshCw size={16} />
        </button>
      </div>
      
      {fact && (
        <div className="text-cosmos-100">
          <TypeAnimation
            sequence={[fact.text]}
            wrapper="p"
            cursor={false}
            speed={70}
            className="leading-relaxed"
          />
        </div>
      )}
    </div>
  );
};

export default FactDisplay;