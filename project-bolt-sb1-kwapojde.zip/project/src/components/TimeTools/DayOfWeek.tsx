import React, { useState } from 'react';
import { Calendar, ArrowRight, Copy } from 'lucide-react';
import FactDisplay from './FactDisplay';

const DayOfWeek: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);

  const calculateDayOfWeek = () => {
    setError(null);
    
    if (!selectedDate) {
      setError('Please select a date');
      return;
    }
    
    try {
      const inputDate = new Date(selectedDate);
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const dayOfWeek = dayNames[inputDate.getDay()];
      
      setResult(dayOfWeek);
      setShowResult(true);
    } catch (err) {
      setError('Invalid date format');
      console.error('Error calculating day of week:', err);
    }
  };

  const copyResult = () => {
    if (result !== null) {
      const textToCopy = `${selectedDate} is a ${result}.`;
      navigator.clipboard.writeText(textToCopy)
        .then(() => {
          console.log('Result copied to clipboard');
        })
        .catch(err => {
          console.error('Failed to copy:', err);
        });
    }
  };

  return (
    <div>
      <div className="space-y-4">
        <div>
          <label htmlFor="date-for-day" className="block text-cosmos-200 mb-2">
            Select a Date
          </label>
          <input
            id="date-for-day"
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="input-field w-full"
          />
          {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
        </div>
        
        <button
          onClick={calculateDayOfWeek}
          className="btn btn-primary w-full flex items-center justify-center space-x-2"
        >
          <span>Show Result</span>
          <ArrowRight size={16} />
        </button>
      </div>
      
      {showResult && result !== null && (
        <div className="mt-6 p-4 bg-space-purple bg-opacity-20 rounded-lg animate-fade-in">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-display text-white">Result</h4>
            <button
              onClick={copyResult}
              className="text-cosmos-300 hover:text-space-glow transition-colors"
              aria-label="Copy result"
            >
              <Copy size={16} />
            </button>
          </div>
          <p className="text-2xl font-display text-space-glow mt-2">
            {result}
          </p>
          <p className="text-cosmos-200 text-sm mt-1">
            {selectedDate} is a {result}
          </p>
          
          <FactDisplay toolName="DayOfWeek" />
        </div>
      )}
    </div>
  );
};

export default DayOfWeek;