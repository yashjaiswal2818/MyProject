import React from 'react';
import { Clock, Rocket, Lightbulb, Code } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <section className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-display font-bold mb-4 text-space-glow">
          About TimeTesseract
        </h1>
        <p className="text-xl text-cosmos-200 max-w-2xl mx-auto">
          A journey through time inspired by the cosmic wonder of Interstellar
        </p>
      </section>

      <section className="mb-16">
        <div className="card-glow mb-8">
          <h2 className="text-2xl md:text-3xl font-display text-white mb-4 flex items-center">
            <Clock className="mr-3 text-space-glow" size={28} />
            Our Mission
          </h2>
          <p className="text-cosmos-200 mb-4">
            TimeTesseract was born from a fascination with how time shapes our universe and our lives. 
            Inspired by the mind-bending concepts in Christopher Nolan's "Interstellar," we set out to 
            create tools that make understanding time both practical and awe-inspiring.
          </p>
          <p className="text-cosmos-200">
            Whether you're calculating days between important events, figuring out time differences across 
            time zones, or simply curious about the day of the week for a future date, TimeTesseract gives 
            you elegant tools with a cosmic perspective.
          </p>
        </div>

        <div className="card-glow">
          <h2 className="text-2xl md:text-3xl font-display text-white mb-6 flex items-center">
            <Lightbulb className="mr-3 text-space-glow" size={28} />
            Features & Capabilities
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-space-dark bg-opacity-40 p-4 rounded-lg">
              <h3 className="text-space-glow font-display mb-2">Time Calculations</h3>
              <p className="text-cosmos-200 text-sm">
                Precise tools for measuring days between dates, determining days from a selected date to today, 
                and calculating time differences down to the second.
              </p>
            </div>
            
            <div className="bg-space-dark bg-opacity-40 p-4 rounded-lg">
              <h3 className="text-space-glow font-display mb-2">Day of Week Tool</h3>
              <p className="text-cosmos-200 text-sm">
                Quickly find what day of the week any date falls on, past or future, to help with planning 
                and scheduling.
              </p>
            </div>
            
            <div className="bg-space-dark bg-opacity-40 p-4 rounded-lg">
              <h3 className="text-space-glow font-display mb-2">Cosmic Facts</h3>
              <p className="text-cosmos-200 text-sm">
                Learn fascinating tidbits about time, space, and the universe with our "Did You Know?" facts 
                that appear with each calculation.
              </p>
            </div>
            
            <div className="bg-space-dark bg-opacity-40 p-4 rounded-lg">
              <h3 className="text-space-glow font-display mb-2">Space-Inspired Design</h3>
              <p className="text-cosmos-200 text-sm">
                An immersive interface with cosmic aesthetics, animated elements, and a design language that 
                echoes the wonder of deep space.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mb-16">
        <div className="card-glow">
          <h2 className="text-2xl md:text-3xl font-display text-white mb-6 flex items-center">
            <Rocket className="mr-3 text-space-glow" size={28} />
            The Future
          </h2>
          <p className="text-cosmos-200 mb-4">
            TimeTesseract is constantly evolving. We're planning to add new features that push the boundaries 
            of how we understand and interact with time:
          </p>
          
          <ul className="space-y-2 text-cosmos-200">
            <li className="flex items-start">
              <span className="text-space-glow mr-2">•</span>
              <span>Time zone converters with visual global maps</span>
            </li>
            <li className="flex items-start">
              <span className="text-space-glow mr-2">•</span>
              <span>Countdowns to astronomical events</span>
            </li>
            <li className="flex items-start">
              <span className="text-space-glow mr-2">•</span>
              <span>Visualizations of time dilation effects at different gravitational forces</span>
            </li>
            <li className="flex items-start">
              <span className="text-space-glow mr-2">•</span>
              <span>Personal time tracking tools with cosmic perspective</span>
            </li>
          </ul>
        </div>
      </section>

      <section className="mb-16">
        <div className="card-glow">
          <h2 className="text-2xl md:text-3xl font-display text-white mb-6 flex items-center">
            <Code className="mr-3 text-space-glow" size={28} />
            Behind the Scenes
          </h2>
          <p className="text-cosmos-200 mb-4">
            TimeTesseract is built using modern web technologies to ensure a smooth, responsive experience:
          </p>
          
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-space-dark bg-opacity-40 p-3 rounded-lg text-center">
              <h3 className="text-space-glow font-display mb-1 text-sm">Frontend</h3>
              <p className="text-cosmos-200 text-xs">React, Tailwind CSS</p>
            </div>
            
            <div className="bg-space-dark bg-opacity-40 p-3 rounded-lg text-center">
              <h3 className="text-space-glow font-display mb-1 text-sm">Backend</h3>
              <p className="text-cosmos-200 text-xs">Node.js, Express</p>
            </div>
            
            <div className="bg-space-dark bg-opacity-40 p-3 rounded-lg text-center">
              <h3 className="text-space-glow font-display mb-1 text-sm">Animation</h3>
              <p className="text-cosmos-200 text-xs">React Type Animation, TsParticles</p>
            </div>
          </div>
          
          <p className="text-cosmos-200 mt-6">
            Our team is passionate about both astronomy and software development, bringing technical expertise
            together with a sense of cosmic wonder to create an application that's both practical and inspiring.
          </p>
        </div>
      </section>
    </div>
  );
};

export default About;