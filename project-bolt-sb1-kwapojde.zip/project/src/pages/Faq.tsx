import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface FaqItemProps {
  question: string;
  answer: string | React.ReactNode;
}

const FaqItem: React.FC<FaqItemProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-cosmos-700 border-opacity-30 py-4">
      <button
        className="flex justify-between items-center w-full text-left focus:outline-none"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
      >
        <h3 className="text-lg font-display text-cosmos-100">{question}</h3>
        <span className="text-cosmos-300 flex-shrink-0 ml-4">
          {isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </span>
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-96 mt-3' : 'max-h-0'
        }`}
      >
        <div className="text-cosmos-200">{answer}</div>
      </div>
    </div>
  );
};

const Faq: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto">
      <section className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-display font-bold mb-4 text-space-glow flex items-center justify-center">
          <HelpCircle className="mr-3" size={32} />
          Frequently Asked Questions
        </h1>
        <p className="text-xl text-cosmos-200 max-w-2xl mx-auto">
          Everything you need to know about TimeTesseract and our time tools
        </p>
      </section>

      <section className="card-glow">
        <div className="space-y-2">
          <FaqItem
            question="How accurate are the time calculations?"
            answer="All of our time calculations are based on the standard JavaScript Date object, which provides precise time calculations according to the user's system clock and timezone settings. Our tools account for leap years, daylight saving time changes, and other calendar complexities."
          />
          
          <FaqItem
            question="Are the 'Did You Know?' facts scientifically accurate?"
            answer="Yes! We've carefully researched all of our cosmic facts to ensure they're scientifically accurate. Many are based on concepts from physics, astronomy, and the mathematical principles that govern time. We also include fun facts about time in popular culture, especially from the movie Interstellar."
          />
          
          <FaqItem
            question="Can I use TimeTesseract offline?"
            answer="Currently, TimeTesseract requires an internet connection to function fully, as some features like the 'Did You Know?' facts are fetched from our server. However, the core calculation tools will work even with intermittent connectivity once the page has loaded."
          />
          
          <FaqItem
            question="How do you handle different timezones?"
            answer="Our date calculations are timezone-aware, meaning if you input dates in your local timezone, the calculations will be correct relative to that timezone. For the Time Difference tool specifically, we maintain the timezone context of your inputs."
          />
          
          <FaqItem
            question="Why is the app named TimeTesseract?"
            answer={
              <div>
                <p className="mb-2">
                  The name combines "Time" with "Tesseract" — a four-dimensional cube that's often used 
                  to represent spacetime in theoretical physics and science fiction.
                </p>
                <p>
                  In the movie Interstellar, a tesseract structure allows the main character to navigate 
                  through time in a visual way. We liked this as a metaphor for our app, which helps you 
                  navigate and understand time with visual tools.
                </p>
              </div>
            }
          />
          
          <FaqItem
            question="Is there a limit to how far in the past or future I can calculate?"
            answer="Our tools can handle dates from January 1, 1970 to December 31, 9999. This range covers historical dates and extends far into the future, allowing for virtually any practical time calculation you might need."
          />
          
          <FaqItem
            question="Do you plan to add more time-related tools?"
            answer="Absolutely! We're continually developing new features based on user feedback. Upcoming tools include time zone converters, countdowns to astronomical events, and more advanced date manipulation utilities. Stay tuned!"
          />
          
          <FaqItem
            question="Can I suggest a new feature or cosmic fact?"
            answer="We welcome suggestions! Feel free to reach out through our contact form or email. We're always looking for new ideas to expand TimeTesseract and make it more useful and fascinating for our users."
          />
          
          <FaqItem
            question="Is my data safe when using TimeTesseract?"
            answer="Yes, your privacy is important to us. All calculations are performed locally in your browser, and we don't store any of the dates or times you input. We do log anonymous usage statistics to help us improve the app, but these never include your personal data."
          />
          
          <FaqItem
            question="Is TimeTesseract free to use?"
            answer="Yes, TimeTesseract is completely free to use! We may add premium features in the future, but the core calculation tools will always remain free and accessible to everyone."
          />
        </div>
      </section>
    </div>
  );
};

export default Faq;