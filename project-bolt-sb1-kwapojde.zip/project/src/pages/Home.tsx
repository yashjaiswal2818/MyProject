import React, { useEffect } from 'react';
import { Calendar, CalendarRange, Clock, CalendarDays } from 'lucide-react';
import TimeToolCard from '../components/TimeTools/TimeToolCard';
import DaysFromDate from '../components/TimeTools/DaysFromDate';
import DayOfWeek from '../components/TimeTools/DayOfWeek';
import DaysBetween from '../components/TimeTools/DaysBetween';
import TimeDifference from '../components/TimeTools/TimeDifference';

const Home: React.FC = () => {
  useEffect(() => {
    if (window.location.hash) {
      const id = window.location.hash.substring(1);
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, []);

  return (
    <div className="flex justify-center gap-4 px-4">
      {/* Left Ad Column - Hidden on mobile */}
      <div className="hidden lg:flex flex-col gap-4 w-[160px]">
        <div className="sticky top-20 flex flex-col gap-4">
          <div className="h-[600px] bg-space-dark bg-opacity-40 rounded-lg flex items-center justify-center">
            <p className="text-cosmos-300 text-sm rotate-[-90deg]">Vertical Ad Space</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl w-full">
        {/* Top Ad Space */}
        <div className="w-full h-32 bg-space-dark bg-opacity-40 rounded-lg mb-8 flex items-center justify-center">
          <p className="text-cosmos-300 text-sm">Advertisement Space</p>
        </div>

        <section className="text-center mb-12 py-10">
          <h1 className="text-4xl md:text-6xl font-display font-bold mb-4 text-space-glow">
            TimeTesseract
          </h1>
          <p className="text-xl md:text-2xl text-cosmos-200 mb-8 max-w-2xl mx-auto">
            Explore the fabric of time with our powerful time calculation tools
          </p>
          <div className="md:flex md:justify-center space-y-4 md:space-y-0 md:space-x-4">
            <a href="#days-from-date" className="btn btn-primary block md:inline-block">
              Get Started
            </a>
            <a href="/about" className="btn btn-secondary block md:inline-block">
              Learn More
            </a>
          </div>
        </section>

        {/* Middle Ad Space */}
        <div className="w-full h-32 bg-space-dark bg-opacity-40 rounded-lg mb-8 flex items-center justify-center">
          <p className="text-cosmos-300 text-sm">Advertisement Space</p>
        </div>

        <section className="space-y-8">
          <h2 className="text-2xl md:text-3xl font-display text-cosmos-100 mb-6">
            Time Exploration Tools
          </h2>

          <TimeToolCard 
            id="days-from-date" 
            title="Days From a Date" 
            icon={<Calendar size={24} />}
          >
            <DaysFromDate />
          </TimeToolCard>

          <TimeToolCard 
            id="day-of-week" 
            title="Day of the Week" 
            icon={<CalendarDays size={24} />}
          >
            <DayOfWeek />
          </TimeToolCard>

          <TimeToolCard 
            id="days-between" 
            title="Days Between Dates" 
            icon={<CalendarRange size={24} />}
          >
            <DaysBetween />
          </TimeToolCard>

          <TimeToolCard 
            id="time-difference" 
            title="Time Difference" 
            icon={<Clock size={24} />}
          >
            <TimeDifference />
          </TimeToolCard>
        </section>

        {/* Bottom Ad Space */}
        <div className="w-full h-32 bg-space-dark bg-opacity-40 rounded-lg my-8 flex items-center justify-center">
          <p className="text-cosmos-300 text-sm">Advertisement Space</p>
        </div>

        <section className="my-16 p-6 rounded-xl bg-space-blue bg-opacity-40 backdrop-blur-md border border-cosmos-700 border-opacity-20">
          <div className="flex flex-col md:flex-row items-center">
            <div className="mb-6 md:mb-0 md:mr-8">
              <h2 className="text-2xl md:text-3xl font-display text-space-glow mb-2">
                Inspired by Interstellar
              </h2>
              <p className="text-cosmos-200">
                TimeTesseract bridges the gap between science fiction and reality, 
                giving you tools to understand how time flows differently across 
                the cosmos—and in your daily life.
              </p>
            </div>
            <div className="w-full md:w-1/3 flex-shrink-0">
              <div className="aspect-square rounded-full bg-space-gradient p-1 animate-glow-pulse">
                <div className="w-full h-full rounded-full bg-space-dark flex items-center justify-center">
                  <Clock className="h-16 w-16 text-space-glow" />
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Right Ad Column - Hidden on mobile */}
      <div className="hidden lg:flex flex-col gap-4 w-[160px]">
        <div className="sticky top-20 flex flex-col gap-4">
          <div className="h-[600px] bg-space-dark bg-opacity-40 rounded-lg flex items-center justify-center">
            <p className="text-cosmos-300 text-sm rotate-[-90deg]">Vertical Ad Space</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;