/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        space: {
          dark: '#0A0E17',
          blue: '#1A2344',
          purple: '#2E1A44',
          accent: '#5D42B7',
          glow: '#64FFDA',
        },
        cosmos: {
          100: '#E6F0FF',
          200: '#C4D7FF',
          300: '#A1BEFF',
          400: '#7FA5FF',
          500: '#5D8BFF',
          600: '#3A72FF',
          700: '#1758FF',
          800: '#0041E6',
          900: '#0033B3',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['"Space Grotesk"', 'sans-serif'],
      },
      animation: {
        'glow-pulse': 'glow-pulse 3s infinite',
        'fade-in': 'fade-in 0.5s ease-in-out',
        'slide-up': 'slide-up 0.5s ease-out',
        'type-blink': 'type-blink 1s step-end infinite',
      },
      keyframes: {
        'glow-pulse': {
          '0%, 100%': { boxShadow: '0 0 10px 2px rgba(100, 255, 218, 0.2)' },
          '50%': { boxShadow: '0 0 20px 5px rgba(100, 255, 218, 0.4)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'slide-up': {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        'type-blink': {
          '0%, 100%': { borderRight: '2px solid rgba(100, 255, 218, 1)' },
          '50%': { borderRight: '2px solid rgba(0, 0, 0, 0)' },
        },
      },
      boxShadow: {
        'glow-sm': '0 0 5px 1px rgba(100, 255, 218, 0.3)',
        'glow-md': '0 0 10px 2px rgba(100, 255, 218, 0.3)',
        'glow-lg': '0 0 15px 3px rgba(100, 255, 218, 0.3)',
      },
      backgroundImage: {
        'space-gradient': 'linear-gradient(to right, #5D42B7, #2E1A44)',
        'button-gradient': 'linear-gradient(to right, #5D8BFF, #5D42B7)',
      },
    },
  },
  plugins: [],
};