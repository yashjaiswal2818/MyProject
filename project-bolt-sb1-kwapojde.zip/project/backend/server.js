import express from 'express';
import cors from 'cors';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files from the React app
app.use(express.static(join(__dirname, '../dist')));

// Load facts from JSON file
const loadFacts = async () => {
  try {
    const data = await fs.readFile(join(__dirname, 'data/facts.json'), 'utf8');
    return JSON.parse(data).facts;
  } catch (error) {
    console.error('Error loading facts:', error);
    return [
      { text: "Time dilation occurs near black holes, where time passes slower due to intense gravity.", category: "physics" },
      { text: "The concept of a tesseract is a 4-dimensional cube, which inspired parts of Interstellar.", category: "interstellar" },
      { text: "The Earth is approximately 4.54 billion years old.", category: "science" },
    ];
  }
};

// API Routes
app.get('/api/fact', async (req, res) => {
  try {
    const facts = await loadFacts();
    const randomFact = facts[Math.floor(Math.random() * facts.length)];
    res.json({ fact: randomFact });
  } catch (error) {
    console.error('Error retrieving fact:', error);
    res.status(500).json({ error: 'Failed to retrieve fact' });
  }
});

app.post('/api/log', (req, res) => {
  const { tool, timestamp } = req.body;
  
  if (!tool || !timestamp) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  
  console.log(`Tool used: ${tool} at ${new Date(timestamp).toISOString()}`);
  res.status(200).json({ success: true });
});

// For any routes not covered by specific API routes, serve the React app
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, '../dist/index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});